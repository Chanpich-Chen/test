import java.util.Scanner;

public class Main {

    public static void validate(int userInput) throws exception { // pass exception to caller
        if (userInput < 0) {
            // create and throw exception
            throw new exception();
        }else {
            System.out.println("Number is :" + userInput);
        }

    }

//    public static void makeChoice(int choice) throws exception {
//        if (!(choice >= 1 && choice <= 5)){
//            throw new exception();
//        }
//        else{
//            System.out.println("You make correct choice: " +choice);
//        }
//    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please input number: ");
        int input = sc.nextInt();

        try {
            validate(input);

        } catch (exception e) {
            // Throw message
            System.err.println(e.getMessage());
        }



    }

}
