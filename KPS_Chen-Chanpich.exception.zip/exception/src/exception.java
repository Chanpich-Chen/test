public class exception extends Exception {

    @Override
   public String getMessage(){
       return "Negative number please input positive number ";
   }
//   public String errorChoice(){
//        return "please input from 1 <=> 5";
//   }

}
